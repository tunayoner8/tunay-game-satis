import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import Home from './pages/Home'
import Category from './pages/Category'
import Product from './pages/Product'
import Cart from './pages/Cart'
import Checkout from './pages/Checkout'
import Order from './pages/Order'
import Admin from './pages/Admin'
import Login from './pages/Login'

function AddToCartRedirect(){
  const loc = useLocation()
  const id = loc.pathname.split('/').pop()
  const cart = JSON.parse(localStorage.getItem("tgs_cart") || "[]")
  cart.push({ id, qty: 1 })
  localStorage.setItem("tgs_cart", JSON.stringify(cart))
  return <Navigate to="/sepet" replace />
}

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/kategori/:name" element={<Category />} />
        <Route path="/urun/:id" element={<Product />} />
        <Route path="/sepete-ekle/:id" element={<AddToCartRedirect />} />
        <Route path="/sepet" element={<Cart />} />
        <Route path="/odeme" element={<Checkout />} />
        <Route path="/siparis/:id" element={<Order />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/giris" element={<Login />} />
      </Routes>
      <Footer />
    </div>
  )
}
