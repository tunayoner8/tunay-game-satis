export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-100 mt-10">
      <div className="container-page py-10 grid md:grid-cols-3 gap-6 text-sm text-gray-600">
        <div>
          <div className="font-semibold text-gray-800 mb-2">Tunay Game Satış</div>
          <p>UCE, hesap ve klan satışlarında hızlı ve güvenilir çözümler.</p>
        </div>
        <div>
          <div className="font-semibold text-gray-800 mb-2">İletişim</div>
          <p>WhatsApp: +90 5xx xxx xx xx</p>
          <p>Instagram: @tunay.games</p>
        </div>
        <div>
          <div className="font-semibold text-gray-800 mb-2">Yasal</div>
          <p>Bu bir demo mağazadır. Gerçek ödeme yoktur.</p>
        </div>
      </div>
    </footer>
  )
}
