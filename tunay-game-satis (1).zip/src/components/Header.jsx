import { Link, NavLink } from 'react-router-dom'

export default function Header() {
  const navClass = ({isActive}) => 
    `px-3 py-2 rounded-xl ${isActive ? 'bg-sky-100 text-sky-700' : 'text-gray-700 hover:bg-gray-100'}`

  return (
    <header className="bg-white border-b border-gray-100 sticky top-0 z-40">
      <div className="container-page flex items-center justify-between h-16">
        <Link to="/" className="font-bold text-xl tracking-tight">
          <span className="text-sky-600">Tunay</span> Game Satış
        </Link>
        <nav className="hidden md:flex gap-2">
          <NavLink to="/kategori/UCE" className={navClass}>UCE</NavLink>
          <NavLink to="/kategori/Hesap" className={navClass}>Hesap</NavLink>
          <NavLink to="/kategori/Klan" className={navClass}>Klan</NavLink>
          <NavLink to="/admin" className={navClass}>Admin</NavLink>
        </nav>
      </div>
    </header>
  )
}
