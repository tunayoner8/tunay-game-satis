import { Link } from 'react-router-dom'

export default function ProductCard({p}) {
  return (
    <div className="card overflow-hidden">
      <img src={p.image} alt={p.title} className="w-full h-44 object-cover"/>
      <div className="p-4">
        <div className="flex items-center justify-between mb-1">
          <h3 className="font-semibold">{p.title}</h3>
          {p.badge && <span className="text-xs bg-sky-100 text-sky-700 px-2 py-1 rounded">{p.badge}</span>}
        </div>
        <div className="text-sky-700 font-bold">{p.price.toLocaleString('tr-TR')} ₺</div>
        <div className="mt-3 flex gap-2">
          <Link to={`/urun/${p.id}`} className="px-3 py-2 rounded-xl bg-black text-white text-sm">İncele</Link>
          <Link to={`/sepete-ekle/${p.id}`} className="px-3 py-2 rounded-xl bg-gray-900/5 text-gray-900 text-sm">Sepete Ekle</Link>
        </div>
      </div>
    </div>
  )
}
