import { loadDB } from '../lib/storage'
import ProductCard from '../components/ProductCard'

export default function Home() {
  const { products } = loadDB()
  return (
    <main className="container-page py-8">
      <section className="mb-8 card p-6">
        <h1 className="text-2xl font-bold mb-2">Hoş geldin!</h1>
        <p className="text-gray-600">Game Satış mağazanda UCE, hesap ve klan ürünlerini listeleyebilir, sipariş alabilir ve admin panelinden içerikleri yönetebilirsin.</p>
      </section>
      <section className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
        {products.map(p => <ProductCard key={p.id} p={p} />)}
      </section>
    </main>
  )
}
