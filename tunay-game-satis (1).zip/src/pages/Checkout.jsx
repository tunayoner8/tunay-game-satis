import { useNavigate } from 'react-router-dom'
import { loadDB, saveDB } from '../lib/storage'

export default function Checkout() {
  const db = loadDB()
  const nav = useNavigate()
  const cart = JSON.parse(localStorage.getItem("tgs_cart") || "[]")
  const items = cart.map(c => ({...db.products.find(p => p.id === c.id), qty: c.qty})).filter(Boolean)
  const total = items.reduce((s, i) => s + i.price * i.qty, 0)

  function placeOrder(e){
    e.preventDefault()
    const fd = new FormData(e.target)
    const order = {
      id: "o_" + Math.random().toString(36).slice(2,9),
      name: fd.get("name"),
      contact: fd.get("contact"),
      note: fd.get("note"),
      items: items.map(i => ({id: i.id, title: i.title, qty: i.qty, price: i.price})),
      total,
      ts: Date.now(),
      status: "Yeni"
    }
    db.orders.push(order)
    saveDB(db)
    localStorage.removeItem("tgs_cart")
    nav(`/siparis/${order.id}`)
  }

  return (
    <main className="container-page py-8">
      <form onSubmit={placeOrder} className="grid md:grid-cols-2 gap-6">
        <div className="card p-6 space-y-4">
          <h2 className="font-semibold">Teslimat Bilgileri</h2>
          <input className="form-input" name="name" placeholder="Ad Soyad" required />
          <input className="form-input" name="contact" placeholder="WhatsApp / Instagram" required />
          <textarea className="form-textarea" name="note" placeholder="Not (ID, oyun adı vb.)"></textarea>
          <button className="px-4 py-2 rounded-xl bg-black text-white">Siparişi Onayla</button>
        </div>
        <div className="card p-6">
          <h2 className="font-semibold mb-4">Özet</h2>
          <ul className="space-y-2 text-sm">
            {items.map(i => <li key={i.id}>{i.title} x{i.qty} — {i.price.toLocaleString('tr-TR')} ₺</li>)}
          </ul>
          <div className="mt-4 font-semibold">Toplam: {total.toLocaleString('tr-TR')} ₺</div>
          <p className="text-xs text-gray-500 mt-3">Demo: Gerçek ödeme yoktur. Siparişler admin paneline düşer.</p>
        </div>
      </form>
    </main>
  )
}
