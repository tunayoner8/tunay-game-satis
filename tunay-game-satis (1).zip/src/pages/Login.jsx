import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { signIn } from '../lib/auth'

export default function Login() {
  const [email, setEmail] = useState('admin@tunaygames.com')
  const [password, setPassword] = useState('Admin123!')
  const nav = useNavigate()

  function handle(e){
    e.preventDefault()
    const s = signIn(email, password)
    if (s) nav('/admin')
    else alert('Hatalı giriş.')
  }

  return (
    <main className="container-page py-8">
      <form onSubmit={handle} className="card p-6 max-w-md mx-auto space-y-3">
        <h1 className="text-xl font-bold">Yönetici Girişi</h1>
        <input className="form-input" value={email} onChange={e=>setEmail(e.target.value)} placeholder="E-posta" />
        <input className="form-input" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Şifre" />
        <button className="px-4 py-2 rounded-xl bg-black text-white">Giriş Yap</button>
        <p className="text-xs text-gray-500">Demo kullanıcı: admin@tunaygames.com / Admin123!</p>
      </form>
    </main>
  )
}
