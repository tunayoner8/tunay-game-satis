import { useParams, Link, useNavigate } from 'react-router-dom'
import { loadDB, saveDB } from '../lib/storage'

export default function Product() {
  const { id } = useParams()
  const db = loadDB()
  const p = db.products.find(x => x.id === id)
  const nav = useNavigate()

  if (!p) return <main className="container-page py-8">Ürün bulunamadı.</main>

  function addToCart() {
    const cart = JSON.parse(localStorage.getItem("tgs_cart") || "[]")
    cart.push({ id: p.id, qty: 1 })
    localStorage.setItem("tgs_cart", JSON.stringify(cart))
    nav("/sepet")
  }

  return (
    <main className="container-page py-8">
      <div className="grid md:grid-cols-2 gap-6">
        <img src={p.image} alt={p.title} className="w-full rounded-2xl object-cover"/>
        <div className="card p-6">
          <h1 className="text-2xl font-bold">{p.title}</h1>
          <div className="text-sky-700 font-bold text-xl mt-2">{p.price.toLocaleString('tr-TR')} ₺</div>
          <p className="text-gray-600 mt-4">{p.desc}</p>
          <div className="mt-6 flex gap-2">
            <button onClick={addToCart} className="px-4 py-2 rounded-xl bg-black text-white">Sepete Ekle</button>
            <Link to="/" className="px-4 py-2 rounded-xl bg-gray-100">Mağazaya Dön</Link>
          </div>
        </div>
      </div>
    </main>
  )
}
