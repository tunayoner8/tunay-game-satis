import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { loadDB, saveDB, resetDB } from '../lib/storage'
import { getSession, signOut } from '../lib/auth'

export default function Admin() {
  const nav = useNavigate()
  const session = getSession()
  const [db, setDb] = useState(loadDB())
  const [form, setForm] = useState({id:'', title:'', price:'', category:'UCE', image:'', stock:0, badge:'', desc:''})

  useEffect(() => {
    if (!session) nav('/giris')
  }, [session, nav])

  function saveProduct(e){
    e.preventDefault()
    const p = {...form, price: parseFloat(form.price || 0), stock: parseInt(form.stock || 0)}
    const exists = db.products.findIndex(x => x.id === p.id)
    if (exists >= 0) db.products[exists] = p
    else {
      p.id = 'p_' + Math.random().toString(36).slice(2,7)
      db.products.push(p)
    }
    saveDB(db)
    setDb({...db})
    setForm({id:'', title:'', price:'', category:'UCE', image:'', stock:0, badge:'', desc:''})
  }

  function editProduct(id){
    const p = db.products.find(x => x.id === id)
    setForm(p)
    window.scrollTo({top: 0, behavior: 'smooth'})
  }

  function deleteProduct(id){
    db.products = db.products.filter(x => x.id !== id)
    saveDB(db)
    setDb({...db})
  }

  function updateOrderStatus(id, status){
    const o = db.orders.find(x => x.id === id)
    if (o) {
      o.status = status
      saveDB(db)
      setDb({...db})
    }
  }

  return (
    <main className="container-page py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Admin Paneli</h1>
        <div className="flex gap-2">
          <button onClick={() => {resetDB(); setDb(loadDB())}} className="px-3 py-2 rounded-xl bg-gray-100 text-sm">Demo Veriyi Sıfırla</button>
          <button onClick={() => {signOut(); nav('/')}} className="px-3 py-2 rounded-xl bg-black text-white text-sm">Çıkış</button>
        </div>
      </div>

      <section className="grid md:grid-cols-2 gap-6">
        <form onSubmit={saveProduct} className="card p-6 space-y-3">
          <h2 className="font-semibold">Ürün Ekle/Düzenle</h2>
          <input className="form-input" placeholder="Başlık" value={form.title} onChange={e => setForm({...form, title:e.target.value})} required />
          <input className="form-input" placeholder="Görsel URL" value={form.image} onChange={e => setForm({...form, image:e.target.value})} required />
          <div className="grid grid-cols-2 gap-3">
            <select className="form-select" value={form.category} onChange={e => setForm({...form, category:e.target.value})}>
              <option>UCE</option>
              <option>Hesap</option>
              <option>Klan</option>
            </select>
            <input className="form-input" type="number" step="0.01" placeholder="Fiyat" value={form.price} onChange={e => setForm({...form, price:e.target.value})} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <input className="form-input" type="number" placeholder="Stok" value={form.stock} onChange={e => setForm({...form, stock:e.target.value})} />
            <input className="form-input" placeholder="Rozet (örn: Hızlı)" value={form.badge} onChange={e => setForm({...form, badge:e.target.value})} />
          </div>
          <textarea className="form-textarea" placeholder="Açıklama" value={form.desc} onChange={e => setForm({...form, desc:e.target.value})}></textarea>
          <button className="px-4 py-2 rounded-xl bg-black text-white">Kaydet</button>
        </form>

        <div className="card p-6">
          <h2 className="font-semibold mb-3">Siparişler</h2>
          {!db.orders.length && <div className="text-sm text-gray-600">Henüz sipariş yok.</div>}
          <ul className="space-y-3">
            {db.orders.map(o => (
              <li key={o.id} className="border rounded-xl p-3">
                <div className="flex items-center justify-between">
                  <div className="font-medium">{o.id}</div>
                  <select className="form-select text-sm" value={o.status} onChange={e => updateOrderStatus(o.id, e.target.value)}>
                    <option>Yeni</option>
                    <option>Hazırlanıyor</option>
                    <option>Teslim Edildi</option>
                    <option>İptal</option>
                  </select>
                </div>
                <div className="text-xs text-gray-600">{o.name} • {o.contact}</div>
                <ul className="mt-2 text-sm">{o.items.map(i => <li key={i.id}>{i.title} x{i.qty}</li>)}</ul>
                <div className="font-semibold mt-2">{o.total.toLocaleString('tr-TR')} ₺</div>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="card p-6 mt-6">
        <h2 className="font-semibold mb-3">Ürünler</h2>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
          {db.products.map(p => (
            <div key={p.id} className="border rounded-xl overflow-hidden">
              <img src={p.image} className="w-full h-36 object-cover"/>
              <div className="p-3">
                <div className="font-medium">{p.title}</div>
                <div className="text-sm text-sky-700">{p.price.toLocaleString('tr-TR')} ₺</div>
                <div className="flex gap-2 mt-2">
                  <button onClick={() => editProduct(p.id)} className="px-3 py-1 rounded-lg bg-gray-100 text-sm">Düzenle</button>
                  <button onClick={() => deleteProduct(p.id)} className="px-3 py-1 rounded-lg bg-red-600 text-white text-sm">Sil</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  )
}
