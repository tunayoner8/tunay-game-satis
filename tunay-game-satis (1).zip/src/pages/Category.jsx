import { useParams, Link } from 'react-router-dom'
import { loadDB } from '../lib/storage'
import ProductCard from '../components/ProductCard'

export default function Category() {
  const { name } = useParams()
  const { products } = loadDB()
  const list = products.filter(p => p.category === name)

  return (
    <main className="container-page py-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold">{name} Ürünleri</h2>
        <Link to="/admin" className="text-sm underline">Admin</Link>
      </div>
      <section className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
        {list.map(p => <ProductCard key={p.id} p={p} />)}
      </section>
    </main>
  )
}
