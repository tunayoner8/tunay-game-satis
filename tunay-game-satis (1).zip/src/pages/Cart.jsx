import { Link, useNavigate } from 'react-router-dom'
import { loadDB } from '../lib/storage'

export default function Cart() {
  const db = loadDB()
  const nav = useNavigate()
  const cart = JSON.parse(localStorage.getItem("tgs_cart") || "[]")
  const items = cart.map(c => ({...db.products.find(p => p.id === c.id), qty: c.qty})).filter(Boolean)
  const total = items.reduce((s, i) => s + i.price * i.qty, 0)

  function checkout() {
    nav("/odeme")
  }

  if (!items.length) {
    return <main className="container-page py-8">
      <div className="card p-6">
        <div>Sepet boş.</div>
        <Link to="/" className="underline mt-2 inline-block">Alışverişe başla</Link>
      </div>
    </main>
  }

  return (
    <main className="container-page py-8">
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 card p-6">
          <h2 className="font-semibold mb-4">Sepet</h2>
          <ul className="space-y-4">
            {items.map(i => (
              <li key={i.id} className="flex items-center gap-4">
                <img src={i.image} className="w-20 h-16 object-cover rounded-xl"/>
                <div className="flex-1">
                  <div className="font-medium">{i.title}</div>
                  <div className="text-sm text-gray-600">{i.price.toLocaleString('tr-TR')} ₺</div>
                </div>
                <div className="text-sm">Adet: {i.qty}</div>
              </li>
            ))}
          </ul>
        </div>
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>Ara Toplam</div>
            <div className="font-semibold">{total.toLocaleString('tr-TR')} ₺</div>
          </div>
          <button onClick={checkout} className="w-full mt-4 px-4 py-2 rounded-xl bg-black text-white">Ödemeye Geç</button>
        </div>
      </div>
    </main>
  )
}
