import { useParams, Link } from 'react-router-dom'
import { loadDB } from '../lib/storage'

export default function Order() {
  const { id } = useParams()
  const db = loadDB()
  const o = db.orders.find(x => x.id === id)

  if (!o) return <main className="container-page py-8">Sipariş bulunamadı.</main>

  return (
    <main className="container-page py-8">
      <div className="card p-6">
        <h1 className="text-xl font-bold">Sipariş Alındı</h1>
        <div className="text-gray-600 mt-1 text-sm">Sipariş kodu: {o.id}</div>
        <ul className="mt-4 space-y-1">
          {o.items.map(i => <li key={i.id}>{i.title} x{i.qty}</li>)}
        </ul>
        <div className="font-semibold mt-3">Toplam: {o.total.toLocaleString('tr-TR')} ₺</div>
        <Link to="/" className="inline-block mt-4 underline">Mağazaya dön</Link>
      </div>
    </main>
  )
}
