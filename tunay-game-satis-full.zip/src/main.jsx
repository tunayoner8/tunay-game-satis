
import React from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'

function App() {
  return (
    <div>
      <h1 className="text-3xl font-bold text-sky-600">Tunay Game Satış</h1>
      <p className="mt-2">Site başarıyla yüklendi 🎮</p>
    </div>
  )
}

createRoot(document.getElementById('root')).render(<App />)
