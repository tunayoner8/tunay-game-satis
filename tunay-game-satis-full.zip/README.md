
# Tunay Game Satış

Bu proje React + Tailwind + Vite ile hazırlanmış bir demo oyun satış sitesidir.

## Çalıştırma
```
npm install
npm run dev
```
## Yayınlama (Vercel)
Build komutu: `npm run build`
Çıktı dizini: `dist`
