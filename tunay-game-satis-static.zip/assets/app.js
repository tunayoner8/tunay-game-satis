
const DB_KEY='tgs_static_db_v1', CART_KEY='tgs_cart_v1', ADMIN_KEY='tgs_admin_ok';
function defaults(){return{products:[
{id:'p1',title:'UCE 1.000 Paket',price:149.90,category:'UCE',image:'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=1200&auto=format&fit=crop',desc:'PUBG Mobile için 1.000 UCE. Hızlı, güvenilir teslim.'},
{id:'p2',title:'Clash of Clans Max TH13',price:2999.00,category:'Hesap',image:'https://images.unsplash.com/photo-1600861194942-f883de0dfe96?q=80&w=1200&auto=format&fit=crop',desc:'Mail change destekli güvenilir hesap.'},
{id:'p3',title:'Mobile Legends Klan Paketi',price:899.00,category:'Klan',image:'https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=1200&auto=format&fit=crop',desc:'Aktif oyunculu, turnuva hazır klan.'}
],orders:[]}};
function loadDB(){try{const r=localStorage.getItem(DB_KEY);if(!r){const d=defaults();localStorage.setItem(DB_KEY,JSON.stringify(d));return d}return JSON.parse(r)}catch{const d=defaults();localStorage.setItem(DB_KEY,JSON.stringify(d));return d}}
function saveDB(db){localStorage.setItem(DB_KEY,JSON.stringify(db))}
function getCart(){try{return JSON.parse(localStorage.getItem(CART_KEY)||'[]')}catch{return []}}
function setCart(c){localStorage.setItem(CART_KEY,JSON.stringify(c))}
function el(h){const t=document.createElement('template');t.innerHTML=h.trim();return t.content.firstChild}

function home(){const db=loadDB();const wrap=el(`<div>
<section class="card hero"><div class="title">VatanGame tarzı koyu tema mağaza</div><p class="small">UCE, Hesap ve Klan ürünleri. Demo ödeme akışı.</p></section>
<section class="grid grid-3" id="grid"></section></div>`);const grid=wrap.querySelector('#grid');db.products.forEach(p=>{const c=el(`<article class="card">
<img src="${p.image}" style="width:100%;height:180px;object-fit:cover"><div class="body">
<div class="row"><h3 style="margin:0">${p.title}</h3><span class="badge">${p.category}</span></div>
<div class="price" style="margin-top:6px">${p.price.toLocaleString('tr-TR')} ₺</div>
<div class="row" style="margin-top:10px"><a class="btn btn-primary" href="#/urun/${p.id}">İncele</a><button class="btn btn-ghost" data-add="${p.id}">Sepete Ekle</button></div>
</div></article>`);c.querySelector('[data-add]').onclick=()=>{const cart=getCart();cart.push({id:p.id,qty:1});setCart(cart);location.hash='#/sepet'};grid.appendChild(c)});return wrap}

function category(name){const db=loadDB();const list=db.products.filter(p=>p.category===name);const wrap=el(`<div><h2>${name} Ürünleri</h2><section class="grid grid-3" id="grid"></section></div>`);const grid=wrap.querySelector('#grid');list.forEach(p=>{const c=el(`<article class="card">
<img src="${p.image}" style="width:100%;height:180px;object-fit:cover"><div class="body">
<div class="row"><h3 style="margin:0">${p.title}</h3><span class="badge">${p.category}</span></div>
<div class="price" style="margin-top:6px">${p.price.toLocaleString('tr-TR')} ₺</div>
<div class="row" style="margin-top:10px"><a class="btn btn-primary" href="#/urun/${p.id}">İncele</a><button class="btn btn-ghost" data-add="${p.id}">Sepete Ekle</button></div>
</div></article>`);c.querySelector('[data-add]').onclick=()=>{const cart=getCart();cart.push({id:p.id,qty:1});setCart(cart);location.hash='#/sepet'};grid.appendChild(c)});return wrap}

function product(id){const db=loadDB();const p=db.products.find(x=>x.id===id);if(!p)return el('<div class="card"><div class="body">Ürün bulunamadı.</div></div>');const wrap=el(`<div class="grid" style="grid-template-columns:1fr 1fr;gap:20px">
<img src="${p.image}" style="width:100%;border-radius:18px;object-fit:cover">
<div class="card"><div class="body"><h1>${p.title}</h1><div class="price">${p.price.toLocaleString('tr-TR')} ₺</div>
<p style="color:#c9c9c9">${p.desc}</p><div class="row"><button class="btn btn-primary" id="add">Sepete Ekle</button><a class="btn btn-ghost" href="#/">Mağazaya Dön</a></div></div></div></div>`);wrap.querySelector('#add').onclick=()=>{const cart=getCart();cart.push({id:p.id,qty:1});setCart(cart);location.hash='#/sepet'};return wrap}

function cart(){const db=loadDB();const cart=getCart();const items=cart.map(c=>({...db.products.find(p=>p.id===c.id),qty:c.qty})).filter(Boolean);const total=items.reduce((s,i)=>s+i.price*i.qty,0);
if(!items.length)return el('<div class="card"><div class="body center">Sepetin boş. <a class="accent" href="#/">Alışverişe başla</a></div></div>');
const wrap=el(`<div class="grid" style="grid-template-columns:2fr 1fr;gap:20px">
<div class="card"><div class="body"><h3>Sepet</h3><table class="table" id="tbl"><thead><tr><th>Ürün</th><th>Adet</th><th>Fiyat</th></tr></thead><tbody></tbody></table></div></div>
<div class="card"><div class="body"><div class="row"><div>Ara Toplam</div><div class="price">${total.toLocaleString('tr-TR')} ₺</div></div><a class="btn btn-primary" href="#/odeme" style="width:100%;margin-top:10px">Ödemeye Geç</a></div></div></div>`);
const tbody=wrap.querySelector('#tbl tbody');items.forEach(i=>{const tr=el(`<tr><td>${i.title}</td><td>${i.qty}</td><td>${i.price.toLocaleString('tr-TR')} ₺</td></tr>`);tbody.appendChild(tr)});return wrap}

function checkout(){const db=loadDB();const cart=getCart();const items=cart.map(c=>({...db.products.find(p=>p.id===c.id),qty:c.qty})).filter(Boolean);const total=items.reduce((s,i)=>s+i.price*i.qty,0);
const wrap=el(`<div class="grid" style="grid-template-columns:1fr 1fr;gap:20px">
<form class="card"><div class="body stack"><h3>Teslimat Bilgileri</h3>
<input class="input" name="name" placeholder="Ad Soyad" required>
<input class="input" name="contact" placeholder="WhatsApp / Instagram" required>
<textarea class="textarea" name="note" placeholder="Not (ID, oyun adı vb.)"></textarea>
<button class="btn btn-primary">Siparişi Onayla</button></div></form>
<div class="card"><div class="body"><h3>Özet</h3>
<ul class="small">${items.map(i=>`<li>${i.title} x${i.qty}</li>`).join('')}</ul>
<div class="row" style="margin-top:8px"><div>Toplam</div><div class="price">${total.toLocaleString('tr-TR')} ₺</div></div>
<p class="small" style="margin-top:10px">Demo: Gerçek ödeme yoktur. Siparişler admin paneline düşer.</p>
</div></div></div>`);
wrap.querySelector('form').onsubmit=(e)=>{e.preventDefault();const fd=new FormData(e.target);
const order={id:'o_'+Math.random().toString(36).slice(2,8),name:fd.get('name'),contact:fd.get('contact'),note:fd.get('note'),
items:items.map(i=>({id:i.id,title:i.title,qty:i.qty,price:i.price})),total,ts:Date.now(),status:'Yeni'};
const db=loadDB();db.orders.push(order);saveDB(db);localStorage.removeItem(CART_KEY);location.hash='#/siparis/'+order.id};return wrap}

function order(id){const db=loadDB();const o=db.orders.find(x=>x.id===id);if(!o)return el('<div class="card"><div class="body">Sipariş bulunamadı.</div></div>');return el(`<div class="card"><div class="body">
<h2>Sipariş Alındı</h2><div class="small">Kod: ${o.id}</div><ul class="small">${o.items.map(i=>`<li>${i.title} x${i.qty}</li>`).join('')}</ul>
<div class="row" style="margin-top:6px"><div>Toplam</div><div class="price">${o.total.toLocaleString('tr-TR')} ₺</div></div>
<a class="btn btn-ghost" href="#/">Mağazaya dön</a></div></div>`)}

function login(){const wrap=el(`<form class="card" style="max-width:380px;margin:40px auto"><div class="body stack">
<h2>Yönetici Girişi</h2><input class="input" name="u" placeholder="Kullanıcı adı" value="admin">
<input class="input" type="password" name="p" placeholder="Şifre" value="1234">
<button class="btn btn-primary">Giriş Yap</button><div class="small">Demo giriş: admin / 1234</div></div></form>`);
wrap.onsubmit=(e)=>{e.preventDefault();const fd=new FormData(wrap);if(fd.get('u')==='admin' && fd.get('p')==='1234'){localStorage.setItem('tgs_admin_ok','1');location.hash='#/admin'}else alert('Kullanıcı adı veya şifre hatalı')};return wrap}

function admin(){if(localStorage.getItem(ADMIN_KEY)!=='1') return login();const db=loadDB();const wrap=el(`<div class="stack">
<div class="row" style="justify-content:space-between"><h2>Yönetici Paneli</h2><div class="row" style="gap:8px"><button class="btn btn-ghost" id="reset">Demo Veriyi Sıfırla</button><button class="btn btn-ghost" id="logout">Çıkış</button></div></div>
<form class="card"><div class="body grid" style="grid-template-columns:1fr 1fr;gap:12px">
<input class="input" name="title" placeholder="Başlık" required>
<input class="input" name="image" placeholder="Görsel URL" required>
<select class="select" name="category"><option>UCE</option><option>Hesap</option><option>Klan</option></select>
<input class="input" name="price" placeholder="Fiyat" required>
<textarea class="textarea" name="desc" placeholder="Açıklama" style="grid-column:1 / -1"></textarea>
<button class="btn btn-primary" style="grid-column:1 / -1">Kaydet</button></div></form>
<section class="grid grid-3" id="list"></section></div>`);
wrap.querySelector('#logout').onclick=()=>{localStorage.removeItem(ADMIN_KEY);location.hash='#/admin'}
wrap.querySelector('#reset').onclick=()=>{localStorage.removeItem(DB_KEY);location.reload()}
wrap.querySelector('form').onsubmit=(e)=>{e.preventDefault();const fd=new FormData(e.target);const p={id:'p_'+Math.random().toString(36).slice(2,7),title:fd.get('title'),image:fd.get('image'),category:fd.get('category'),price:parseFloat(fd.get('price')),desc:fd.get('desc')};const db=loadDB();db.products.push(p);saveDB(db);location.reload()}
const list=wrap.querySelector('#list');db.products.forEach(p=>{const card=el(`<article class="card">
<img src="${p.image}" style="width:100%;height:140px;object-fit:cover"><div class="body">
<div class="row"><div class="small">${p.category}</div><div class="price">${p.price.toLocaleString('tr-TR')} ₺</div></div>
<div style="font-weight:700">${p.title}</div>
<div class="row" style="margin-top:8px"><a class="btn btn-primary" href="#/urun/${p.id}">Gör</a><button class="btn btn-ghost" data-del="${p.id}">Sil</button></div>
</div></article>`);card.querySelector('[data-del]').onclick=()=>{const db=loadDB();db.products=db.products.filter(x=>x.id!==p.id);saveDB(db);location.reload()};list.appendChild(card)})
return wrap}

function router(){const root=document.getElementById('app');root.innerHTML='';const [_,seg,a]=location.hash.split('/');let view;switch(seg){case'kategori':view=category(a);break;case'urun':view=product(a);break;case'sepet':view=cart();break;case'odeme':view=checkout();break;case'siparis':view=order(a);break;case'admin':view=admin();break;default:view=home()}root.appendChild(view)}
addEventListener('hashchange',router);addEventListener('load',router);
