
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: { extend: { colors: { bg: "#0f0f0f", panel: "#141414", soft: "#1d1d1d", accent: "#e50914" } } },
  plugins: [require("@tailwindcss/forms")]
}
