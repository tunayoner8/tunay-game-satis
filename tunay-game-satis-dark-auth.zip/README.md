
# Tunay Game Satış (Koyu Tema, Admin Şifreli)
- Admin: **admin / 1234**  ( /admin )
- Vite + React + Tailwind
- Build: `npm run build` → Output: `dist`
