
export default function Footer(){
  return (
    <footer className="mt-10 border-t border-soft">
      <div className="container-page py-10 grid md:grid-cols-3 gap-6 text-sm text-white/70">
        <div><div className="font-semibold text-white mb-2">Tunay Game Satış</div><p>Koyu tema, hızlı teslimat, güvenilir satış.</p></div>
        <div><div className="font-semibold text-white mb-2">İletişim</div><p>WhatsApp: +90 5xx xxx xx xx</p><p>Instagram: @tunay.games</p></div>
        <div><div className="font-semibold text-white mb-2">Not</div><p>Demo mağaza — gerçek ödeme yoktur.</p></div>
      </div>
    </footer>
  )
}
