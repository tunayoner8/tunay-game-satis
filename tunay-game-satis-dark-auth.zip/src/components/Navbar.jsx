
import { NavLink, Link } from 'react-router-dom'
export default function Navbar(){
  const link = ({isActive}) => `px-3 py-2 rounded-xl hover:bg-soft ${isActive ? 'text-[var(--accent)]' : 'text-white/80'}`
  return (
    <header className="sticky top-0 z-40 border-b border-soft bg-bg/80 backdrop-blur">
      <div className="container-page h-16 flex items-center justify-between">
        <Link to="/" className="font-bold text-xl tracking-tight"><span className="text-[var(--accent)]">Tunay</span> Game Satış</Link>
        <nav className="hidden md:flex gap-2">
          <NavLink to="/kategori/UCE" className={link}>UCE</NavLink>
          <NavLink to="/kategori/Hesap" className={link}>Hesap</NavLink>
          <NavLink to="/kategori/Klan" className={link}>Klan</NavLink>
          <NavLink to="/admin" className={link}>Admin</NavLink>
          <NavLink to="/sepet" className={link}>Sepet</NavLink>
        </nav>
      </div>
    </header>
  )
}
