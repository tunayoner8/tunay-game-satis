
import { loadDB } from '../lib/storage'
import ProductCard from '../components/ProductCard'
export default function Home(){
  const { products } = loadDB()
  return (
    <main className="container-page py-8">
      <section className="card p-6 mb-8">
        <h1 className="text-2xl font-bold">VatanGame tarzı koyu tema mağaza</h1>
        <p className="text-white/70">UCE, Hesap ve Klan ürünleri. Demo ödeme akışı.</p>
      </section>
      <section className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
        {products.map(p => <ProductCard key={p.id} p={p} />)}
      </section>
    </main>
  )
}
