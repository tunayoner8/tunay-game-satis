
import { useEffect, useState } from 'react'
import { loadDB, saveDB, resetDB } from '../lib/storage'
const USER="admin", PASS="1234"
function Login({onOk}){
  function submit(e){
    e.preventDefault(); const fd=new FormData(e.target)
    if(fd.get('u')===USER && fd.get('p')===PASS){ localStorage.setItem('tgs_admin','1'); onOk() }
    else alert('Kullanıcı adı veya şifre hatalı')
  }
  return (<form onSubmit={submit} className="card p-6 max-w-sm mx-auto mt-16 space-y-3">
    <h1 className="text-xl font-bold">Yönetici Girişi</h1>
    <input name="u" placeholder="Kullanıcı adı" defaultValue="admin" className="form-input bg-soft border-soft text-white"/>
    <input name="p" placeholder="Şifre" type="password" defaultValue="1234" className="form-input bg-soft border-soft text-white"/>
    <button className="btn btn-primary w-full">Giriş Yap</button>
    <p className="text-xs text-white/60">Demo: admin / 1234</p>
  </form>)
}
export default function Admin(){
  const [ok,setOk]=useState(false)
  const [db,setDb]=useState(loadDB())
  const [form,setForm]=useState({id:'',title:'',price:'',category:'UCE',image:'',desc:''})
  useEffect(()=>{ setOk(localStorage.getItem('tgs_admin')==='1') },[])
  if(!ok) return <Login onOk={()=>setOk(true)}/>
  function save(e){
    e.preventDefault()
    const p={...form, price: parseFloat(form.price||0)}
    const idx=db.products.findIndex(x=>x.id===p.id)
    if(idx>=0) db.products[idx]=p; else { p.id='p_'+Math.random().toString(36).slice(2,7); db.products.push(p) }
    saveDB(db); setDb({...db}); setForm({id:'',title:'',price:'',category:'UCE',image:'',desc:''})
  }
  function edit(id){ const p=db.products.find(x=>x.id===id); if(p) setForm(p) }
  function del(id){ db.products=db.products.filter(x=>x.id!==id); saveDB(db); setDb({...db}) }
  return (<main className="container-page py-8 space-y-6">
    <div className="flex items-center justify-between">
      <h1 className="text-2xl font-bold">Yönetici Paneli</h1>
      <button onClick={()=>{resetDB(); setDb(loadDB())}} className="btn btn-ghost">Demo Veriyi Sıfırla</button>
    </div>
    <form onSubmit={save} className="card p-6 grid md:grid-cols-2 gap-3">
      <input className="form-input bg-soft border-soft text-white" placeholder="Başlık" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} required/>
      <input className="form-input bg-soft border-soft text-white" placeholder="Görsel URL" value={form.image} onChange={e=>setForm({...form,image:e.target.value})} required/>
      <select className="form-select bg-soft border-soft text-white" value={form.category} onChange={e=>setForm({...form,category:e.target.value})}><option>UCE</option><option>Hesap</option><option>Klan</option></select>
      <input className="form-input bg-soft border-soft text-white" placeholder="Fiyat" value={form.price} onChange={e=>setForm({...form,price:e.target.value})}/>
      <textarea className="form-textarea bg-soft border-soft text-white md:col-span-2" placeholder="Açıklama" value={form.desc} onChange={e=>setForm({...form,desc:e.target.value})}></textarea>
      <button className="btn btn-primary md:col-span-2">Kaydet</button>
    </form>
    <section className="card p-6">
      <h2 className="font-semibold mb-3">Ürünler</h2>
      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
        {db.products.map(p=>(
          <div key={p.id} className="bg-soft rounded-xl overflow-hidden">
            <img src={p.image} className="w-full h-36 object-cover"/>
            <div className="p-3">
              <div className="font-medium">{p.title}</div>
              <div className="text-[var(--accent)]">{p.price.toLocaleString('tr-TR')} ₺</div>
              <div className="flex gap-2 mt-2">
                <button onClick={()=>edit(p.id)} className="btn btn-ghost">Düzenle</button>
                <button onClick={()=>del(p.id)} className="btn btn-primary">Sil</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  </main>)
}
