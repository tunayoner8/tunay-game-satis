
import { Link, useNavigate } from 'react-router-dom'
import { loadDB } from '../lib/storage'
export default function Cart(){
  const db = loadDB()
  const nav = useNavigate()
  const cart = JSON.parse(localStorage.getItem("tgs_cart") || "[]")
  const items = cart.map(c => ({...db.products.find(p => p.id === c.id), qty: c.qty})).filter(Boolean)
  const total = items.reduce((s, i) => s + i.price * i.qty, 0)
  if(!items.length){
    return <main className="container-page py-8">
      <div className="card p-6">
        <div>Sepetin boş.</div>
        <Link to="/" className="underline mt-2 inline-block text-[var(--accent)]">Alışverişe başla</Link>
      </div>
    </main>
  }
  function checkout(){ nav("/odeme") }
  return (
    <main className="container-page py-8">
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 card p-6">
          <h2 className="font-semibold mb-4">Sepet</h2>
          <ul className="space-y-4">
            {items.map(i => (
              <li key={i.id} className="flex items-center gap-4">
                <img src={i.image} className="w-20 h-16 object-cover rounded-xl"/>
                <div className="flex-1">
                  <div className="font-medium">{i.title}</div>
                  <div className="text-sm text-white/70">{i.price.toLocaleString('tr-TR')} ₺</div>
                </div>
                <div className="text-sm">Adet: {i.qty}</div>
              </li>
            ))}
          </ul>
        </div>
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>Ara Toplam</div>
            <div className="font-semibold">{total.toLocaleString('tr-TR')} ₺</div>
          </div>
          <button onClick={checkout} className="btn btn-primary w-full mt-4">Ödemeye Geç</button>
        </div>
      </div>
    </main>
  )
}
