
import { useParams, useNavigate, Link } from 'react-router-dom'
import { loadDB } from '../lib/storage'
export default function Product(){
  const { id } = useParams()
  const db = loadDB()
  const p = db.products.find(x => x.id === id)
  const nav = useNavigate()
  if(!p) return <main className="container-page py-8">Ürün bulunamadı.</main>
  function add(){
    const cart = JSON.parse(localStorage.getItem("tgs_cart") || "[]")
    cart.push({ id: p.id, qty: 1 })
    localStorage.setItem("tgs_cart", JSON.stringify(cart))
    nav("/sepet")
  }
  return (
    <main className="container-page py-8">
      <div className="grid md:grid-cols-2 gap-6">
        <img className="w-full rounded-2xl object-cover" src={p.image} alt={p.title}/>
        <div className="card p-6">
          <h1 className="text-2xl font-bold">{p.title}</h1>
          <div className="text-[var(--accent)] font-bold text-xl mt-2">{p.price.toLocaleString('tr-TR')} ₺</div>
          <p className="text-white/70 mt-3">{p.desc}</p>
          <div className="mt-6 flex gap-2">
            <button onClick={add} className="btn btn-primary">Sepete Ekle</button>
            <Link to="/" className="btn btn-ghost">Mağazaya Dön</Link>
          </div>
        </div>
      </div>
    </main>
  )
}
