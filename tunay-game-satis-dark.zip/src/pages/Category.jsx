import { useParams } from 'react-router-dom'
import { loadDB } from '../lib/storage'
import ProductCard from '../components/ProductCard'
export default function Category(){
  const { name } = useParams()
  const { products } = loadDB()
  const list = products.filter(p => p.category === name)
  return (
    <main className="container-page py-8">
      <h2 className="text-xl font-bold mb-6">{name} Ürünleri</h2>
      <section className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
        {list.map(p => <ProductCard key={p.id} p={p} />)}
      </section>
    </main>
  )
}
