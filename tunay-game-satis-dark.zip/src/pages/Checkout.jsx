import { useNavigate } from 'react-router-dom'
import { loadDB, saveDB } from '../lib/storage'
export default function Checkout(){
  const db = loadDB()
  const nav = useNavigate()
  const cart = JSON.parse(localStorage.getItem("tgs_cart") || "[]")
  const items = cart.map(c => ({...db.products.find(p => p.id === c.id), qty: c.qty})).filter(Boolean)
  const total = items.reduce((s, i) => s + i.price * i.qty, 0)
  function place(e){
    e.preventDefault()
    const fd = new FormData(e.target)
    const order = {
      id: "o_" + Math.random().toString(36).slice(2,8),
      name: fd.get("name"),
      contact: fd.get("contact"),
      note: fd.get("note"),
      items: items.map(i => ({id: i.id, title: i.title, qty: i.qty, price: i.price})),
      total, ts: Date.now(), status: "Yeni"
    }
    db.orders.push(order); saveDB(db)
    localStorage.removeItem("tgs_cart")
    nav(`/siparis/${order.id}`)
  }
  return (
    <main className="container-page py-8 grid md:grid-cols-2 gap-6">
      <form onSubmit={place} className="card p-6 space-y-3">
        <h2 className="font-semibold">Teslimat Bilgileri</h2>
        <input className="form-input bg-soft border-soft text-white" name="name" placeholder="Ad Soyad" required/>
        <input className="form-input bg-soft border-soft text-white" name="contact" placeholder="WhatsApp / Instagram" required/>
        <textarea className="form-textarea bg-soft border-soft text-white" name="note" placeholder="Not (ID, oyun adın vb.)"></textarea>
        <button className="btn btn-primary">Siparişi Onayla</button>
      </form>
      <div className="card p-6">
        <h2 className="font-semibold mb-3">Özet</h2>
        <ul className="text-sm space-y-1">{items.map(i => <li key={i.id}>{i.title} x{i.qty}</li>)}</ul>
        <div className="font-semibold mt-3">Toplam: {total.toLocaleString('tr-TR')} ₺</div>
        <p className="text-xs text-white/60 mt-3">Demo: Gerçek ödeme yoktur. Siparişler admin paneline düşer.</p>
      </div>
    </main>
  )
}
