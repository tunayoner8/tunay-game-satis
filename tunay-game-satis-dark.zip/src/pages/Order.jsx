import { useParams, Link } from 'react-router-dom'
import { loadDB } from '../lib/storage'
export default function Order(){
  const { id } = useParams()
  const db = loadDB()
  const o = db.orders.find(x => x.id === id)
  if(!o) return <main className="container-page py-8">Sipariş bulunamadı.</main>
  return (
    <main className="container-page py-8">
      <div className="card p-6">
        <h1 className="text-xl font-bold">Sipariş Alındı</h1>
        <div className="text-white/70 text-sm">Kod: {o.id}</div>
        <ul className="mt-3">{o.items.map(i => <li key={i.id}>{i.title} x{i.qty}</li>)}</ul>
        <div className="font-semibold mt-2">Toplam: {o.total.toLocaleString('tr-TR')} ₺</div>
        <Link to="/" className="underline text-[var(--accent)] mt-4 inline-block">Mağazaya dön</Link>
      </div>
    </main>
  )
}
