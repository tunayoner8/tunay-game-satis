import { Routes, Route, Navigate } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Home from './pages/Home'
import Category from './pages/Category'
import Product from './pages/Product'
import Cart from './pages/Cart'
import Checkout from './pages/Checkout'
import Order from './pages/Order'
import Admin from './pages/Admin'

function AddToCart(){
  const id = location.pathname.split('/').pop()
  const cart = JSON.parse(localStorage.getItem("tgs_cart") || "[]")
  cart.push({ id, qty: 1 })
  localStorage.setItem("tgs_cart", JSON.stringify(cart))
  return <Navigate to="/sepet" replace />
}

export default function App(){
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/kategori/:name" element={<Category/>} />
        <Route path="/urun/:id" element={<Product/>} />
        <Route path="/sepete-ekle/:id" element={<AddToCart/>} />
        <Route path="/sepet" element={<Cart/>} />
        <Route path="/odeme" element={<Checkout/>} />
        <Route path="/siparis/:id" element={<Order/>} />
        <Route path="/admin" element={<Admin/>} />
      </Routes>
      <Footer />
    </div>
  )
}
