import { Link } from 'react-router-dom'
export default function ProductCard({p}){
  return (
    <div className="card overflow-hidden">
      <img src={p.image} alt={p.title} className="w-full h-44 object-cover"/>
      <div className="p-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">{p.title}</h3>
          <span className="text-xs bg-[var(--accent)]/10 text-[var(--accent)] px-2 py-1 rounded">Stok: {p.stock ?? 1}</span>
        </div>
        <div className="text-[var(--accent)] font-extrabold mt-1">{p.price.toLocaleString('tr-TR')} ₺</div>
        <div className="mt-3 flex gap-2">
          <Link className="btn btn-primary" to={`/urun/${p.id}`}>İncele</Link>
          <Link className="btn btn-ghost" to={`/sepete-ekle/${p.id}`}>Sepete Ekle</Link>
        </div>
      </div>
    </div>
  )
}
