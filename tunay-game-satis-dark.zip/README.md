# Tunay Game Satış (Koyu Tema - VatanGame Tarzı)

- Vite + React + Tailwind
- Sayfalar: Anasayfa, Kategori, Ürün, Sepet, Ödeme, Sipariş, Admin
- Veriler: localStorage (ücretsiz, backend gerekmez)

## Lokalde Çalıştır
npm install
npm run dev

## Vercel Ayarları
Build Komutu: npm run build
Çıktı Dizini: dist
