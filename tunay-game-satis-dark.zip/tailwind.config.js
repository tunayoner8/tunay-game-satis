export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0f0f0f",
        panel: "#151515",
        soft: "#1e1e1e",
        accent: "#e50914"
      }
    },
  },
  plugins: [require("@tailwindcss/forms")]
}
